package com.example.springsecurityapplication.controllers;

import com.example.springsecurityapplication.repositories.ProductRepository;
import com.example.springsecurityapplication.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/product")
public class MainController {



//    12.02  00:20:22 внедряем репозиторий
    private final ProductRepository productRepository;



    private final ProductService productService;
    @Autowired
    public MainController(ProductRepository productRepository, ProductService productService) {
        this.productRepository = productRepository;
        this.productService = productService;
    }

//  список товаров для незарегистрированных
    @GetMapping("")
    public String getAllProduct(Model model){
        model.addAttribute("products", productService.getAllProduct());
        return "product/product";
    }


//  обработка перехода на info/{id} с карточкой товара
    @GetMapping("/info/{id}")
    public String infoProduct(@PathVariable("id") int id, Model model){
        model.addAttribute(("product"), productService.getProductId(id));
        return "product/infoProduct";
    }




//Обработка формы сортировки
//   @RequestParam(value = "price", required = false, defaultValue = "") - для случаев когда параметр как может придти так может и не придти с формы
    @PostMapping("/search")
    public String indexSearch(@RequestParam("search") String search, @RequestParam("from") String from, @RequestParam("to") String to, @RequestParam(value = "price", required = false, defaultValue = "") String price, @RequestParam(value = "category", required = false, defaultValue = "") String category, Model model){



//обработка методов сортировки (продолжение)
//  поля от и до заполнены
        if (!from.isEmpty() & !to.isEmpty()){
//  выбрана какая-либо сортировка по цене
            if(!price.isEmpty()){
//  выбрана сортировка по возрастанию цены товара
                if(price.equals("sorted_by_ascending_price")){
//  выбрана какая-либо категория
                    if(!category.isEmpty()) {
                        if (category.equals("furniture")) {
                            //  search.toLowerCase() - поисковое выражение введенное пользователем в поле "Поиск по ниаменованию" переводим в нижний регистр
                            //  Float.parseFloat(from) переводим параметр из поля "from" из строки в float (1вое слово - тип в который конвертируем, далее парсим в него через parseFloat)
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 5));
                        } else if (category.equals("dishes")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 6));
                        } else if (category.equals("electronics")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 7));
                        } else if (category.equals("cars")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 8));
                        }
//  не выбрана ниодна категория
                    } else {
                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to)));
                    }
//  выбрана сортировка по убыванию цены товара
                }else if(price.equals("sorted_by_descending_price")){
//  выбрана какая-либо категория
                    if(!category.isEmpty()) {
                        if (category.equals("furniture")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 5));
                        } else if (category.equals("dishes")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 6));
                        } else if (category.equals("electronics")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 7));
                        } else if (category.equals("cars")) {
                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 8));
                        }
//  не выбрана ни одна категория
                    } else {
                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceDesc(search.toLowerCase(),Float.parseFloat(from), Float.parseFloat(to)));
                    }
                }
//  НЕ выбран тип сортировки по цене
            } else {
//  выбрана какая-либо категория
                if(!category.isEmpty()) {
                    if (category.equals("furniture")) {
                        model.addAttribute("search_product", productRepository.findByTitlePriceCategory(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 5));
                    } else if (category.equals("dishes")) {
                        model.addAttribute("search_product", productRepository.findByTitlePriceCategory(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 6));
                    } else if (category.equals("electronics")) {
                        model.addAttribute("search_product", productRepository.findByTitlePriceCategory(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 7));
                    } else if (category.equals("cars")) {
                        model.addAttribute("search_product", productRepository.findByTitlePriceCategory(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to), 8));
                    }
//  не выбрана ни одна категория
                } else {
                    model.addAttribute("search_product", productRepository.findByTitleAndPriceGreaterThanEqualAndPriceLessThan(search.toLowerCase(), Float.parseFloat(from), Float.parseFloat(to)));
                }
            }
//  поля от и до НЕ заполнены
    //  если заполненно только наименование
        } else {
//  выбрана сортировка по цене
            if(!price.isEmpty()){
//  сортировка по возрастанию
                if(price.equals("sort_by_asc")){
                    if(!category.isEmpty()) {
                        if (category.equals("furniture")) {
                            model.addAttribute("search_product", productRepository.findByTitleCategoryOrderByPriceAsc(search.toLowerCase(), 5));
                        } else if (category.equals("dishes")) {
                            model.addAttribute("search_product", productRepository.findByTitleCategoryOrderByPriceAsc(search.toLowerCase(), 6));
                        } else if (category.equals("electronics")) {
                            model.addAttribute("search_product", productRepository.findByTitleCategoryOrderByPriceAsc(search.toLowerCase(), 7));
                        } else if (category.equals("cars")) {
                            model.addAttribute("search_product", productRepository.findByTitleCategoryOrderByPriceAsc(search.toLowerCase(), 8));
                        }
                    }else {
                            model.addAttribute("search_product", productRepository.findByTitleOrderByPriceAsc(search.toLowerCase()));
                    }
//  сортировка по убыванию
                }else if(price.equals("sorted_by_descending_price")){
                    if(!category.isEmpty()) {
                        if (category.equals("furniture")) {
                            model.addAttribute("search_product", productRepository.findByTitleCategoryOrderByPriceDesc(search.toLowerCase(), 5));
                        } else if (category.equals("dishes")) {
                            model.addAttribute("search_product", productRepository.findByTitleCategoryOrderByPriceDesc(search.toLowerCase(), 6));
                        } else if (category.equals("electronics")) {
                            model.addAttribute("search_product", productRepository.findByTitleCategoryOrderByPriceDesc(search.toLowerCase(), 7));
                        } else if (category.equals("cars")) {
                            model.addAttribute("search_product", productRepository.findByTitleCategoryOrderByPriceDesc(search.toLowerCase(), 8));
                        }
                    }else {
                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceDesc(search.toLowerCase()));
                    }
                }
//  НЕ выбрана сортировка по цене
            } else {
                if(!category.isEmpty()){
                    if (category.equals("furniture")) {
                        model.addAttribute("search_product", productRepository.findByTitleCategory(search.toLowerCase(), 5));
                    } else if (category.equals("dishes")) {
                        model.addAttribute("search_product", productRepository.findByTitleCategory(search.toLowerCase(), 6));
                    } else if (category.equals("electronics")) {
                        model.addAttribute("search_product", productRepository.findByTitleCategory(search.toLowerCase(), 7));
                    } else if (category.equals("cars")) {
                        model.addAttribute("search_product", productRepository.findByTitleCategory(search.toLowerCase(), 8));
                    }
                }else{
                    model.addAttribute("search_product", productRepository.findByTitleContainingIgnoreCase(search));
                }
            }
        }


//при перезагрузке поля сортировок не очищаются
    model.addAttribute("value_search", search);
    model.addAttribute("value_price_from", from);
    model.addAttribute("value_price_to", to);
//  строчка ниже нужна чтобы полный список продуктов и далее присутствовал на страничке но уже ниже результатов поиска
    model.addAttribute("products", productService.getAllProduct());

        return "product/product";
    }

    @PostMapping("/search1")
    public String indexSearch1(@RequestParam("search1") String search1, @RequestParam("from1") String from1, @RequestParam("to1") String to1, @RequestParam(value = "price", required = false, defaultValue = "") String price, @RequestParam(value = "category", required = false, defaultValue = "") String category, Model model){



//обработка методов сортировки (продолжение)
//  поля от и до заполнены
        if (!from1.isEmpty() & !to1.isEmpty()){
//  выбрана какая-либо сортировка по цене
            if(!price.isEmpty()){
//  выбрана сортировка по возрастанию цены товара
                if(price.equals("sorted_by_ascending_price")){
//  выбрана какая-либо категория
                    if(!category.isEmpty()) {
                        if (category.equals("furniture")) {
                            //  search.toLowerCase() - поисковое выражение введенное пользователем в поле "Поиск по ниаменованию" переводим в нижний регистр
                            //  Float.parseFloat(from) переводим параметр из поля "from" из строки в float (1вое слово - тип в который конвертируем, далее парсим в него через parseFloat)
                            model.addAttribute("search_product1", productRepository.findByTitleAndCategoryOrderByPriceAsc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 5));
                        } else if (category.equals("dishes")) {
                            model.addAttribute("search_product1", productRepository.findByTitleAndCategoryOrderByPriceAsc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 6));
                        } else if (category.equals("electronics")) {
                            model.addAttribute("search_product1", productRepository.findByTitleAndCategoryOrderByPriceAsc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 7));
                        } else if (category.equals("cars")) {
                            model.addAttribute("search_product1", productRepository.findByTitleAndCategoryOrderByPriceAsc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 8));
                        }
//  не выбрана ниодна категория
                    } else {
                        model.addAttribute("search_product1", productRepository.findByTitleOrderByPriceAsc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1)));
                    }
//  выбрана сортировка по убыванию цены товара
                }else if(price.equals("sorted_by_descending_price")){
//  выбрана какая-либо категория
                    if(!category.isEmpty()) {
                        if (category.equals("furniture")) {
                            model.addAttribute("search_product1", productRepository.findByTitleAndCategoryOrderByPriceDesc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 5));
                        } else if (category.equals("dishes")) {
                            model.addAttribute("search_product1", productRepository.findByTitleAndCategoryOrderByPriceDesc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 6));
                        } else if (category.equals("electronics")) {
                            model.addAttribute("search_product1", productRepository.findByTitleAndCategoryOrderByPriceDesc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 7));
                        } else if (category.equals("cars")) {
                            model.addAttribute("search_product1", productRepository.findByTitleAndCategoryOrderByPriceDesc(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 8));
                        }
//  не выбрана ни одна категория
                    } else {
                        model.addAttribute("search_product1", productRepository.findByTitleOrderByPriceDesc(search1.toLowerCase(),Float.parseFloat(from1), Float.parseFloat(to1)));
                    }
                }
//  НЕ выбран тип сортировки по цене
            } else {
//  выбрана какая-либо категория
                if(!category.isEmpty()) {
                    if (category.equals("furniture")) {
                        model.addAttribute("search_product1", productRepository.findByTitlePriceCategory(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 5));
                    } else if (category.equals("dishes")) {
                        model.addAttribute("search_product1", productRepository.findByTitlePriceCategory(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 6));
                    } else if (category.equals("electronics")) {
                        model.addAttribute("search_product1", productRepository.findByTitlePriceCategory(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 7));
                    } else if (category.equals("cars")) {
                        model.addAttribute("search_product1", productRepository.findByTitlePriceCategory(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1), 8));
                    }
//  не выбрана ни одна категория
                } else {
                    model.addAttribute("search_product1", productRepository.findByTitleAndPriceGreaterThanEqualAndPriceLessThan(search1.toLowerCase(), Float.parseFloat(from1), Float.parseFloat(to1)));
                }
            }
//  поля от и до НЕ заполнены
            //  если заполненно только наименование
        } else {
//  выбрана сортировка по цене
            if(!price.isEmpty()){
//  сортировка по возрастанию
                if(price.equals("sorted_by_ascending_price")){
                    if(!category.isEmpty()) {
                        if (category.equals("furniture")) {
                            model.addAttribute("search_product1", productRepository.findByTitleCategoryOrderByPriceAsc(search1.toLowerCase(), 5));
                        } else if (category.equals("dishes")) {
                            model.addAttribute("search_product1", productRepository.findByTitleCategoryOrderByPriceAsc(search1.toLowerCase(), 6));
                        } else if (category.equals("electronics")) {
                            model.addAttribute("search_product1", productRepository.findByTitleCategoryOrderByPriceAsc(search1.toLowerCase(), 7));
                        } else if (category.equals("cars")) {
                            model.addAttribute("search_product1", productRepository.findByTitleCategoryOrderByPriceAsc(search1.toLowerCase(), 8));
                        }
                    }else {
                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceAsc(search1.toLowerCase()));
                    }
//  сортировка по убыванию
                }else if(price.equals("sorted_by_descending_price")){
                    if(!category.isEmpty()) {
                        if (category.equals("furniture")) {
                            model.addAttribute("search_product1", productRepository.findByTitleCategoryOrderByPriceDesc(search1.toLowerCase(), 5));
                        } else if (category.equals("dishes")) {
                            model.addAttribute("search_product1", productRepository.findByTitleCategoryOrderByPriceDesc(search1.toLowerCase(), 6));
                        } else if (category.equals("electronics")) {
                            model.addAttribute("search_product1", productRepository.findByTitleCategoryOrderByPriceDesc(search1.toLowerCase(), 7));
                        } else if (category.equals("cars")) {
                            model.addAttribute("search_product1", productRepository.findByTitleCategoryOrderByPriceDesc(search1.toLowerCase(), 8));
                        }
                    }else {
                        model.addAttribute("search_product1", productRepository.findByTitleOrderByPriceDesc(search1.toLowerCase()));
                    }
                }
//  НЕ выбрана сортировка по цене
            } else {
                if(!category.isEmpty()){
                    if (category.equals("furniture")) {
                        model.addAttribute("search_product1", productRepository.findByTitleCategory(search1.toLowerCase(), 5));
                    } else if (category.equals("dishes")) {
                        model.addAttribute("search_product1", productRepository.findByTitleCategory(search1.toLowerCase(), 6));
                    } else if (category.equals("electronics")) {
                        model.addAttribute("search_product1", productRepository.findByTitleCategory(search1.toLowerCase(), 7));
                    } else if (category.equals("cars")) {
                        model.addAttribute("search_product1", productRepository.findByTitleCategory(search1.toLowerCase(), 8));
                    }
                }else{
                    model.addAttribute("search_product1", productRepository.findByTitleContainingIgnoreCase(search1));
                }
            }
        }


//при перезагрузке поля сортировок не очищаются
        model.addAttribute("value_search1", search1);
        model.addAttribute("value_price_from1", from1);
        model.addAttribute("value_price_to1", to1);
//  строчка ниже нужна чтобы полный список продуктов и далее присутствовал на страничке но уже ниже результатов поиска
        model.addAttribute("products", productService.getAllProduct());

        return "/user/index";
    }







}
